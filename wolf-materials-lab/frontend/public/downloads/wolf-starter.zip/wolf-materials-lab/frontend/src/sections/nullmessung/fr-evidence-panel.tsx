'use client';

import { useMemo, useState } from 'react';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Alert from '@mui/material/Alert';
import Table from '@mui/material/Table';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import TableRow from '@mui/material/TableRow';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import Typography from '@mui/material/Typography';
import TableContainer from '@mui/material/TableContainer';

import { Label } from 'src/components/label';
import { Iconify } from 'src/components/iconify';

import {
  frEvent,
  frVersionV1,
  frVersionV2,
  frNovexFinding,
  frCurrentTotalRows,
  frVersionV2ChangeNote,
} from 'src/data/fr-evidence';

// Track 1 (Procurement evidence engine) - FR primary case.
// Layout modeled on SpendDrilldown's Dialog/Table row shape
// (nullmessung/spend-drilldown.tsx) and the approve/reset button pattern
// from dashboard/components/page.tsx:24,50.
//
// Step 4: finding + evidence rows + approval control (done).
// Step 5 (this file): D1 stale-approval rule. An approval stores the event
// id it was approved against (approvedAtVersion). If the active FR event
// changes (a simulated correction, UPD-FR-003-demo) after approval, the
// sup-aster approval flips to stale and is blocked from re-approval as-is;
// the unrelated sup-novex approval is untouched because it never depended
// on UPD-FR-002/003's version. Idempotent replay of the *same* event and
// the HU guard case are step 6 (scripts/verify_replay_and_hu.py), not UI.
//
// Step 6b (this file, bottom section): optional DeepSeek explainer. Calls
// the EXISTING POST /api/analyse route (frontend/src/app/api/analyse/route.ts)
// server-side only - no client-side key, no new endpoint. That route already
// falls back to a labelled demo response (X-Wolf-Mode: demo) when
// WOLF_MODEL_BASE_URL/WOLF_MODEL_NAME are unset, and calls the model
// (X-Wolf-Mode: model) when they are set. This panel only displays the
// returned text; it never feeds into totalEUR, isStale, or any replay/HU
// logic above - those are byte-identical whether this section is used or not.

const fmtNum = (v: number) =>
  v.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

type AsterApproval = { approvedAtVersion: string | null };
type NovexApproval = { approved: boolean };

export function FrEvidencePanel() {
  const [version, setVersion] = useState<'v1' | 'v2'>('v1');
  const [aster, setAster] = useState<AsterApproval>({ approvedAtVersion: null });
  const [novex, setNovex] = useState<NovexApproval>({ approved: false });

  const active = version === 'v1' ? frVersionV1 : frVersionV2;
  const totalEUR = useMemo(() => active.rows.reduce((s, r) => s + r.netValueEUR, 0), [active]);

  // D1: approval is bound to the version it was approved against. It is
  // stale the moment the active event id no longer matches that version -
  // never inferred from "did the numbers actually change".
  const isStale = aster.approvedAtVersion !== null && aster.approvedAtVersion !== active.eventId;
  const isApprovedCurrent = aster.approvedAtVersion === active.eventId;

  const handleApproveAster = () => setAster({ approvedAtVersion: active.eventId });
  const handleResetAster = () => setAster({ approvedAtVersion: null });
  const handleApplyCorrection = () => setVersion('v2');
  const handleResetVersion = () => {
    setVersion('v1');
    setAster({ approvedAtVersion: null });
  };

  const handleApproveNovex = () => setNovex({ approved: true });
  const handleResetNovex = () => setNovex({ approved: false });

  const [explainer, setExplainer] = useState<{
    loading: boolean;
    text: string | null;
    mode: 'demo' | 'model' | null;
    error: string | null;
  }>({ loading: false, text: null, mode: null, error: null });

  const handleExplain = async () => {
    setExplainer({ loading: true, text: null, mode: null, error: null });
    try {
      const res = await fetch('/api/analyse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            {
              role: 'user',
              text:
                `Explain this procurement finding in plain language for a buyer. ` +
                `Event ${active.eventId} (${frEvent.mode}), scope ${frEvent.scopeSupplierId}. ` +
                `Recomputed total: ${fmtNum(totalEUR)} EUR across ${active.rows.length} rows. ` +
                `Approval status: ${isStale ? 'stale, needs re-review' : isApprovedCurrent ? 'approved' : 'not yet approved'}.`,
            },
          ],
        }),
      });
      const text = await res.text();
      const mode = res.headers.get('X-Wolf-Mode') === 'model' ? 'model' : 'demo';
      if (!res.ok) {
        setExplainer({ loading: false, text: null, mode, error: text || `HTTP ${res.status}` });
        return;
      }
      setExplainer({ loading: false, text, mode, error: null });
    } catch (err) {
      setExplainer({
        loading: false,
        text: null,
        mode: null,
        error: err instanceof Error ? err.message : 'Explainer call failed.',
      });
    }
  };

  return (
    <Stack spacing={2} sx={{ px: 3, pb: 3 }}>
      <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap alignItems="center">
        <Label color="info">active version: {active.eventId}</Label>
        <Label color="warning">scope: {frEvent.scopeSupplierId}</Label>
        <Label color="default">
          {frEvent.mode} · {frCurrentTotalRows} rows total in FR
        </Label>
        {isStale && <Label color="error">STALE — re-review required</Label>}
        {isApprovedCurrent && <Label color="success">Approved locally</Label>}
        {!aster.approvedAtVersion && <Label color="warning">Needs review</Label>}
      </Stack>

      <Typography variant="body2" sx={{ color: 'text.secondary' }}>
        sup-aster finding, recomputed from {active.eventId}: {fmtNum(totalEUR)} € across{' '}
        {active.rows.length} in-scope rows. Independent of the dashboard ledger (DATASET.md:26) —
        never summed into the 4,872-row canonical total.
      </Typography>

      {version === 'v2' && (
        <Alert severity="warning" icon={<Iconify icon="solar:danger-triangle-bold" />}>
          {frVersionV2ChangeNote} Any approval made on {frVersionV1.eventId} is now stale.
        </Alert>
      )}

      <TableContainer sx={{ maxHeight: 360 }}>
        <Table size="small" stickyHeader sx={{ '& td, & th': { whiteSpace: 'nowrap' } }}>
          <TableHead>
            <TableRow>
              <TableCell>Source row</TableCell>
              <TableCell>Site</TableCell>
              <TableCell>Invoice</TableCell>
              <TableCell>Article</TableCell>
              <TableCell align="right">Qty</TableCell>
              <TableCell align="right">Net value</TableCell>
              <TableCell>Type</TableCell>
              <TableCell>Payer (name, col23)</TableCell>
              <TableCell>Payer (code, col34)</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {active.rows.map((r) => {
              const changed = version === 'v2' && r.sourceRow === 2;
              return (
                <TableRow key={`${r.invoice}-${r.sourceRow}`} hover selected={changed}>
                  <TableCell sx={{ color: 'text.secondary', fontVariantNumeric: 'tabular-nums' }}>
                    {r.sourceFile}:{r.sourceRow}
                  </TableCell>
                  <TableCell>{r.siteCode}</TableCell>
                  <TableCell>{r.invoice}</TableCell>
                  <TableCell>{r.article}</TableCell>
                  <TableCell align="right" sx={{ fontVariantNumeric: 'tabular-nums' }}>
                    {r.qty.toLocaleString('en-GB')}
                  </TableCell>
                  <TableCell
                    align="right"
                    sx={{
                      fontVariantNumeric: 'tabular-nums',
                      fontWeight: changed ? 700 : 400,
                      color: r.netValueEUR < 0 ? 'error.main' : changed ? 'warning.dark' : 'text.primary',
                    }}
                  >
                    {fmtNum(r.netValueEUR)} € {changed && '(corrected)'}
                  </TableCell>
                  <TableCell>
                    <Label color={r.invoiceTypeCode === 'CREDIT_NOTE' ? 'error' : 'default'} variant="soft">
                      {r.invoiceTypeCode}
                    </Label>
                  </TableCell>
                  <TableCell sx={{ color: 'text.secondary' }}>{r.payerName}</TableCell>
                  <TableCell sx={{ color: 'text.secondary' }}>{r.payerCode}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>

      <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
        {!isStale ? (
          <Button
            variant="contained"
            startIcon={<Iconify icon="solar:check-circle-bold" />}
            onClick={handleApproveAster}
            disabled={isApprovedCurrent}
          >
            {isApprovedCurrent ? 'Approved locally' : 'Approve FR finding'}
          </Button>
        ) : (
          <Button variant="contained" color="error" disabled startIcon={<Iconify icon="solar:danger-triangle-bold" />}>
            Stale — blocked, re-review required
          </Button>
        )}
        <Button variant="outlined" onClick={handleResetAster} disabled={!aster.approvedAtVersion}>
          Reset approval
        </Button>

        <Divider orientation="vertical" flexItem />

        <Button
          variant="outlined"
          color="warning"
          onClick={handleApplyCorrection}
          disabled={version === 'v2'}
        >
          Simulate corrected event (demo)
        </Button>
        <Button variant="text" onClick={handleResetVersion} disabled={version === 'v1'}>
          Reset to {frVersionV1.eventId}
        </Button>
      </Stack>

      <Divider sx={{ borderStyle: 'dashed' }} />

      <Stack spacing={1}>
        <Typography variant="subtitle2">Unrelated approval (isolation check)</Typography>
        <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
          <Label color="default">sup-novex baseline · {frNovexFinding.rowCount} rows</Label>
          <Typography variant="body2" sx={{ color: 'text.secondary' }}>
            {fmtNum(frNovexFinding.totalEUR)} € — out of scope for {frEvent.id} and{' '}
            {frVersionV2.eventId}
          </Typography>
          {novex.approved ? (
            <Label color="success">Approved locally</Label>
          ) : (
            <Label color="warning">Needs review</Label>
          )}
          <Button size="small" variant="contained" onClick={handleApproveNovex} disabled={novex.approved}>
            {novex.approved ? 'Approved locally' : 'Approve sup-novex baseline'}
          </Button>
          <Button size="small" variant="outlined" onClick={handleResetNovex} disabled={!novex.approved}>
            Reset
          </Button>
        </Stack>
        <Typography variant="caption" sx={{ color: 'text.disabled' }}>
          Applying the sup-aster correction above must never change this approval's state - proves
          scope isolation (D5).
        </Typography>
      </Stack>

      <Divider sx={{ borderStyle: 'dashed' }} />

      <Stack spacing={1}>
        <Typography variant="subtitle2">Optional explainer (step 6b, not load-bearing)</Typography>
        <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
          <Button
            size="small"
            variant="outlined"
            startIcon={<Iconify icon="solar:chat-round-dots-bold" />}
            onClick={handleExplain}
            disabled={explainer.loading}
          >
            {explainer.loading ? 'Asking…' : 'Explain finding (DeepSeek)'}
          </Button>
          {explainer.mode && (
            <Label color={explainer.mode === 'model' ? 'success' : 'default'} variant="soft">
              X-Wolf-Mode: {explainer.mode}
            </Label>
          )}
        </Stack>
        {explainer.error && (
          <Alert severity="error" sx={{ mt: 0.5 }}>
            {explainer.error}
          </Alert>
        )}
        {explainer.text && (
          <Typography
            variant="body2"
            sx={{ mt: 0.5, p: 1.5, borderRadius: 1, bgcolor: 'background.neutral', whiteSpace: 'pre-wrap' }}
          >
            {explainer.text}
          </Typography>
        )}
        <Typography variant="caption" sx={{ color: 'text.disabled' }}>
          Calls the existing POST /api/analyse route server-side only. Falls back to a labelled
          demo response when WOLF_MODEL_BASE_URL/WOLF_MODEL_NAME are unset - the total, stale flag
          and replay/HU results above never depend on this call succeeding.
        </Typography>
      </Stack>

      <Box sx={{ flexGrow: 1 }} />
      <Typography variant="caption" sx={{ color: 'text.disabled' }}>
        Local UI state only, no persistence. Idempotent replay of {frEvent.id} and the HU
        add_supplier guard case are verified separately (scripts/verify_replay_and_hu.py).
      </Typography>
    </Stack>
  );
}
